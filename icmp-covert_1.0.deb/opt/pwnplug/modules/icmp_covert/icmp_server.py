#!/usr/bin/env python3
from scapy.all import *

KEY = 0x55
FRAME_START = 2
FRAME_END = 3

buffer = []
capturing = False


def decrypt_char(c):
    return chr(c ^ KEY)


def handle(pkt):
    global capturing, buffer

    if ICMP in pkt and pkt[ICMP].type == 8:
        code = pkt[ICMP].code

        if code == FRAME_START:
            buffer = []
            capturing = True
            return

        if code == FRAME_END:
            print("[+] Message received:")
            print("".join(buffer))
            capturing = False
            return

        if capturing:
            buffer.append(decrypt_char(code))


sniff(filter="icmp", prn=handle, store=False)

