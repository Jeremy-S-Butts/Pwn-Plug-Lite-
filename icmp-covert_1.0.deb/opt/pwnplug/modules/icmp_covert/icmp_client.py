#!/usr/bin/env python3
from scapy.all import *
import time

TARGET_IP = "10.10.10.8"
DELAY = 0.05
KEY = 0x55

FRAME_START = 2
FRAME_END = 3


def encrypt_char(c):
    return ord(c) ^ KEY


def send_code(code):
    pkt = IP(dst=TARGET_IP) / ICMP(type=8, code=code)
    send(pkt, verbose=False)
    time.sleep(DELAY)


def transmit(message):
    send_code(FRAME_START)

    for char in message:
        send_code(encrypt_char(char))

    send_code(FRAME_END)


if __name__ == "__main__":
    transmit("Hello from covert ICMP")
