Python 3.14.0 (tags/v3.14.0:ebf955d, Oct  7 2025, 10:15:03) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
#!/usr/bin/env python3
"""
PwnPlug Lite - Network Credential Sniffer Module
------------------------------------------------
Scans packet captures (.pcap) for plaintext or weakly encoded credentials
across FTP, SMTP, and Telnet protocols.

Author: CyberGeekJSB (Jeremy Butts)
Compatible with: PwnPlug Lite v2.x+
Dependencies: scapy, base64, re
Usage:
    sudo python3 pwnplug_sniffer_creds.py <pcapfile>
"""

from scapy.all import *
from base64 import b64decode
import re
import sys
import os
from datetime import datetime

# -------------------- CONFIGURATION -------------------- #
LOG_DIR = "/opt/pwnplug/logs"
LOG_FILE = os.path.join(LOG_DIR, "credsniff.log")

# Ensure log directory exists
os.makedirs(LOG_DIR, exist_ok=True)

# -------------------- LOGGING UTILITY -------------------- #
def log(msg):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    entry = f"{timestamp} {msg}"
    print(entry)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(entry + "\n")

# -------------------- FTP EXTRACTION -------------------- #
def extract_ftp(packet):
    try:
        payload = packet[Raw].load.decode("utf-8", errors="ignore").rstrip()
        if payload[:4].upper() == "USER":
            log(f"[FTP USER] {packet[IP].dst}:{packet[TCP].dport} → {payload[5:]}")
        elif payload[:4].upper() == "PASS":
            log(f"[FTP PASS] {packet[IP].dst}:{packet[TCP].dport} → {payload[5:]}")
    except:
        return

# -------------------- SMTP EXTRACTION -------------------- #
email_regex = r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"
unmatched_smtp = []

def extract_smtp(packet):
    try:
        raw_data = packet[Raw].load
        decoded = b64decode(raw_data).decode("utf-8", errors="ignore")
        conn_data = (packet[IP].src, packet[TCP].sport)

        if re.search(email_regex, decoded):
            log(f"[SMTP USER] {packet[IP].dst}:{packet[TCP].dport} → {decoded}")
            unmatched_smtp.append(conn_data)
        elif conn_data in unmatched_smtp:
            log(f"[SMTP PASS] {packet[IP].dst}:{packet[TCP].dport} → {decoded}")
            unmatched_smtp.remove(conn_data)
    except:
        return

# -------------------- TELNET EXTRACTION -------------------- #
awaiting_login = []
awaiting_pass = []

def extract_telnet(packet):
    try:
        payload = packet[Raw].load.decode("utf-8", errors="ignore").rstrip()
        conn_data = (packet[IP].src, packet[TCP].sport)
        if "login" in payload.lower():
            awaiting_login.append(conn_data)
        elif "password" in payload.lower():
            awaiting_pass.append(conn_data)

        conn_data_resp = (packet[IP].dst, packet[TCP].dport)
        if conn_data_resp in awaiting_login:
...             log(f"[TELNET USER] {packet[IP].dst}:{packet[TCP].dport} → {payload}")
...             awaiting_login.remove(conn_data_resp)
...         elif conn_data_resp in awaiting_pass:
...             log(f"[TELNET PASS] {packet[IP].dst}:{packet[TCP].dport} → {payload}")
...             awaiting_pass.remove(conn_data_resp)
...     except:
...         return
... 
... # -------------------- MAIN DISPATCH -------------------- #
... def process_pcap(file_path):
...     log(f"[*] Starting credential scan on {file_path}")
...     packets = rdpcap(file_path)
... 
...     for packet in packets:
...         if not packet.haslayer(TCP) or not packet.haslayer(Raw):
...             continue
... 
...         sport, dport = packet[TCP].sport, packet[TCP].dport
... 
...         # FTP
...         if 21 in (sport, dport):
...             extract_ftp(packet)
...         # SMTP
...         elif 25 in (sport, dport):
...             extract_smtp(packet)
...         # Telnet
...         elif 23 in (sport, dport):
...             extract_telnet(packet)
... 
...     log("[*] Credential scan completed.\n")
... 
... # -------------------- ENTRY POINT -------------------- #
... if __name__ == "__main__":
...     if len(sys.argv) < 2:
...         print("Usage: sudo python3 pwnplug_sniffer_creds.py <pcapfile>")
...         sys.exit(1)
...     process_pcap(sys.argv[1])
